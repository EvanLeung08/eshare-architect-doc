package com.smartrm.infracore.idgenerator;

/**
 * @author: liuyuancheng
 * @description: 唯一id生成器接口
 */
public interface UniqueIdGenerator {

  long next();
}
