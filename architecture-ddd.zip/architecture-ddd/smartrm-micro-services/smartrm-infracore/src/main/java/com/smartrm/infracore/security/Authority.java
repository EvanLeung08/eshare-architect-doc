package com.smartrm.infracore.security;

/**
 * @author: liuyuancheng
 * @description:
 */
public enum Authority {
  OpenCabinet;
}
