package com.smartrm.smartrmtrade.trade.domain;

/**
 * @author: liuyuancheng
 * @description:
 */
public class DeviceFailure {

}
