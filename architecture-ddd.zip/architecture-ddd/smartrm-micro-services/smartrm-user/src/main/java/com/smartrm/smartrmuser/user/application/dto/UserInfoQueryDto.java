package com.smartrm.smartrmuser.user.application.dto;

/**
 * @author: liuyuancheng
 * @description:
 */
public class UserInfoQueryDto {

  String openId;

  public String getOpenId() {
    return openId;
  }

  public void setOpenId(String openId) {
    this.openId = openId;
  }
}
