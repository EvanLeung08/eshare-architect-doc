package com.smartrm.smartrmmonolith.payment.application.dto;

/**
 * @author: liuyuancheng
 * @description:
 */
public class WxPayerDto {

  private String openid;

  public String getOpenid() {
    return openid;
  }

  public void setOpenid(String openid) {
    this.openid = openid;
  }
}
