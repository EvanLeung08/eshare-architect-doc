package com.smartrm.smartrmmonolith.infracore.security;

/**
 * @author: liuyuancheng
 * @description:
 */
public enum Authority {
  OpenCabinet;
}
