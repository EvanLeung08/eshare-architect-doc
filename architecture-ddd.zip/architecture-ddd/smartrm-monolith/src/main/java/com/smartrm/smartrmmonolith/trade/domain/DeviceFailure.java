package com.smartrm.smartrmmonolith.trade.domain;

/**
 * @author: liuyuancheng
 * @description:
 */
public class DeviceFailure {

}
