package com.smartrm.smartrmmonolith.operation.adapter.erp.model;

/**
 * @author: liuyuancheng
 * @description: 售卖机供应信息
 */
public class VendingMachineSupplyInfo {

}
