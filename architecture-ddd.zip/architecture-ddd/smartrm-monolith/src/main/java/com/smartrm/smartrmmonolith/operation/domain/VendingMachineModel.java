package com.smartrm.smartrmmonolith.operation.domain;

import com.smartrm.smartrmmonolith.device.domain.DeviceModel;

/**
 * @author: liuyuancheng
 * @description: 售卖机型号
 */
public class VendingMachineModel {

  private DeviceModel model;
  
  private VendingMachineCapacityInfo capacityInfo;

}
