package com.smartrm.smartrmmonolith.infracore.api;

public interface ErrorCode {

  int getCode();

  String getMsg();
}
