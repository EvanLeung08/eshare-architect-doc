package com.smartrm.smartrmmonolith.infracore.common;

/**
 * @author: liuyuancheng
 * @description:
 */
public class MathUtil {

  public static int HASH_MAGIC_NUMBER = 169065 * 179;

}
