## 本工程以自动贩卖机为例

/smartrm-micro-services 微服务版本
/smartrm-monolith 单体版本

## 领域概念

### 建模

用户故事、通用语言文档

Domain Storytelling
https://domainstorytelling.org/quick-start-guide
https://www.wps.de/modeler/

### 微服务

界线上下文

### 领域


核心域、领域划分、子域

聚合根/值对象/实体/领域对象/

资源库（持久化）

领域服务

事件风暴发

防腐层
